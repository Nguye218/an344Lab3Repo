/*
 * MemoryTools.h
 *
 *  Created on: Oct 22, 2021
 *      Author: ASUS
 */

#ifndef MEMORYTOOLS_H_
#define MEMORYTOOLS_H_

INT16U MemChkSum(INT8U *startaddr, INT8U *endaddr);

#endif /* MEMORYTOOLS_H_ */

